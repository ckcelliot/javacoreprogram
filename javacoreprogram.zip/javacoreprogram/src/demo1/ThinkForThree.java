package demo1;

import java.util.Arrays;

public class ThinkForThree {
    public static int[] array = new int[]{-10, 20, 30, -40, -50, 60, 70, -80, -90}; // int i
    public static int[] array1 = new int[3]; // int j
    public static int[] array2 = new int[3]; // int j
    public static int[] array3 = new int[3]; // int j

    public static void main(String[] args) {
        for (int i = 0, j = 0; i < array.length; i += 3, j++) {
            array1[j] = array[i]; // 0 -> 3 -> 6
            array2[j] = array[i + 1]; // 1 -> 4 -> 7
            array3[j] = array[i + 2]; // 2 -> 5 -> 8
        }

        System.out.println(Arrays.toString(array1));
        System.out.println(Arrays.toString(array2));
        System.out.println(Arrays.toString(array3));
    }
}
