package demo1;

public class StringLength {
    public static void main(String[] args) {
        String message = "Hello, Java!";
        int length = message.length();
        System.out.println(length);

        System.out.println("-----------");

        System.out.println("Hello, Java!".length());
    }
}
