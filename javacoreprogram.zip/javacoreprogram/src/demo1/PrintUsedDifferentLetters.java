package demo1;

import java.util.Scanner;

public class PrintUsedDifferentLetters {
    public static void main(String[] args) {
        String string;
        char char1;
        int number;

        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter something else...");
        string = sc.nextLine();
        string = string.toUpperCase();

        number = 0;
        System.out.println("Used letters as followed:");
        for (char1 = 'A'; char1 <='Z'; char1++){
            for (int i = 0; i < string.length(); i++){
                if (char1 == string.charAt(i)){
                    //System.out.println(char1 + "\t"); // println => message on new line
                    System.out.print(char1 + "\t"); // print => message on same line
                    number++;
                    break;
                }
            }
        }
        System.out.println("\nTotal number of used different letters are:" + number);
    }
}
