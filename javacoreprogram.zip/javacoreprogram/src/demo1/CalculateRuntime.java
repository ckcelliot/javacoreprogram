package demo1;

import java.util.Scanner;

public class CalculateRuntime {
    public static void main(String[] args) {
        long startTime; // Start time
        long endTime;   // End time
        double timeDifference; // Time difference

        startTime = System.currentTimeMillis();

        System.out.print("Enter you name: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();

        System.out.println("Thanks "+ name +" ! ");

        endTime = System.currentTimeMillis();
        timeDifference = (endTime - startTime) / 1000.0;

        System.out.println("\nThe program runtime is: " + timeDifference);
    }

}
